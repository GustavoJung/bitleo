import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class FirestoreService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  static final _uid = FirebaseAuth.instance.currentUser!.uid;
  static final _doc = FirebaseFirestore.instance.collection('users').doc(_uid);

  Future<void> createUserDocument({
    required String uid,
    required Map<String, dynamic> data,
  }) async {
    await _firestore.collection('users').doc(uid).set({
      ...data,
      'atributos': {
        'Oratória': 0,
        'Liderança': 0,
        'Empatia': 0,
        'Organização': 0,
      },
      'pontosDeAtributo': 3,
      'status': {
        'dinheiro': 30,
        'inteligencia': 5,
        'felicidade': 70,
        'saude': 70,
        'xp': 0,
        'idade': 18,
        'cargo': 'Pré-LEO',
      },
      'historico': [],
      'distribuiuInicial': false,
      'tutorialVisto': false,
      'ultimoXPParaPontos': 0,
      'conquistas': [],
      'conquistasDesbloqueadas': [],
      'conquistasResgatadas': [],
      'telasVisitadas': [],
    });
  }

  static Future<Map<String, int>> progressoConquistas() async {
    final doc = await _doc.get();
    final data = doc.data();
    if (data == null) return {};

    final Map<String, dynamic> progressoRaw = data['progressoConquistas'] ?? {};
    // Garante cast correto (às vezes Firestore traz como double)
    final Map<String, int> progresso = {};
    progressoRaw.forEach((key, value) {
      progresso[key] = (value as num).toInt();
    });

    return progresso;
  }

  static Future<void> incrementarProgressoConquista(
    String titulo, [
    int incremento = 1,
  ]) async {
    final doc = await _doc.get();
    final Map<String, dynamic> progresso = Map<String, dynamic>.from(
      doc.data()?['progressoConquistas'] ?? {},
    );
    progresso[titulo] = (progresso[titulo] ?? 0) + incremento;
    await _doc.set({'progressoConquistas': progresso}, SetOptions(merge: true));
  }

  static Future<void> checarDesbloqueios({
    required int xp,
    required int acoes,
    int? oratoria,
    int? saude,
    int? felicidadeAlta,
    bool? pontosDistribuidos,
    int? empatia,
    int? lideranca,
    int? organizacao,
    int? inteligencia,
    int? campanhas,
    int? estudou,
    int? trabalhou,
    int? mentorou,
    int? eventosOrganizados,
    int? reunioesParticipadas,
    int? redesSociais,
    int? reunioesDistritais,
  }) async {
    // XP total
    if (xp >= 10) await desbloquear('Começando a Jornada');
    if (xp >= 50) await desbloquear('Primeiro Passo de Liderança');
    if (xp >= 200) await desbloquear('Persistente');
    if (xp >= 400) await desbloquear('Mito do Clube');
    // Contagem de ações gerais
    if (acoes >= 10) await desbloquear('Ativo no clube');
    if (acoes >= 100) await desbloquear('Jogador Ativo');
    // Oratória
    if ((oratoria ?? 0) >= 10) await desbloquear('Fala Bonita!');
    if ((oratoria ?? 0) >= 20) await desbloquear('Orador Avançado');
    // Saúde
    if ((saude ?? 0) >= 100) await desbloquear('Cura Total');
    // Felicidade alta várias vezes seguidas
    if ((felicidadeAlta ?? 0) >= 5) await desbloquear('Treta Controlada');
    // Distribuiu todos os pontos iniciais
    if (pontosDistribuidos == true) await desbloquear('Estrategista');
    // Empatia
    if ((empatia ?? 0) >= 10) await desbloquear('Empatia em Alta');
    if ((empatia ?? 0) >= 20) await desbloquear('Coração de Ouro');
    // Liderança
    if ((lideranca ?? 0) >= 10) await desbloquear('Potencial de Líder');
    if ((lideranca ?? 0) >= 25) await desbloquear('Líder Inspirador');
    // Organização
    if ((organizacao ?? 0) >= 10) await desbloquear('Organizado(a)');
    if ((organizacao ?? 0) >= 20) await desbloquear('Mestre da Organização');
    // Inteligência
    if ((inteligencia ?? 0) >= 15) await desbloquear('Cabeça Pensante');
    if ((inteligencia ?? 0) >= 30) await desbloquear('Gênio do LEO');
    // Campanhas feitas
    if ((campanhas ?? 0) >= 10) await desbloquear('Engajador de Campanhas');
    if ((campanhas ?? 0) >= 25) await desbloquear('Lenda das Campanhas');
    // Estudo
    if ((estudou ?? 0) >= 10) await desbloquear('Estudante Aplicado');
    // Trabalhou
    if ((trabalhou ?? 0) >= 10) await desbloquear('Trabalhador Dedicado');
    // Mentorou novatos
    if ((mentorou ?? 0) >= 5) await desbloquear('Mentor da Galera');
    // Eventos organizados
    if ((eventosOrganizados ?? 0) >= 5)
      await desbloquear('Organizador Profissional');
    // Participação em reuniões
    if ((reunioesParticipadas ?? 0) >= 10)
      await desbloquear('Presença Garantida');
    // Redes sociais
    if ((redesSociais ?? 0) >= 10) await desbloquear('Influencer LEO');
    // Reuniões distritais
    if ((reunioesDistritais ?? 0) >= 3)
      await desbloquear('Embaixador Regional');
  }

  Future<DocumentSnapshot<Map<String, dynamic>>> getUserDocument(String uid) {
    return _firestore.collection('users').doc(uid).get();
  }

  Future<void> updateUserName(String uid, String nome) async {
    await _firestore.collection('usuarios').doc(uid).set({
      'nome': nome,
    }, SetOptions(merge: true));
  }

  static Future<void> salvarConquistas(List<String> conquistas) async {
    await _doc.set({'conquistas': conquistas}, SetOptions(merge: true));
  }

  static Future<List<String>> carregarConquistas() async {
    final doc = await _doc.get();
    return List<String>.from(doc.data()?['conquistas'] ?? []);
  }

  // Atributos
  static Future<void> salvar(Map<String, int> atributos) async {
    await _doc.set({'atributos': atributos}, SetOptions(merge: true));
  }

  static Future<Map<String, int>> carregar() async {
    final snap = await _doc.get();
    final dados = snap.data()?['atributos'] as Map<String, dynamic>? ?? {};
    return dados.map((k, v) => MapEntry(k, v as int));
  }

  // Pontos
  static Future<void> salvarPontos(int pontos) async {
    await _doc.set({'pontosDeAtributo': pontos}, SetOptions(merge: true));
  }

  static Future<int> carregarPontos() async {
    final snap = await _doc.get();
    return (snap.data()?['pontosDeAtributo'] ?? 0) as int;
  }

  // Status
  static Future<void> salvarStatus(Map<String, dynamic> status) async {
    await _doc.set({'status': status}, SetOptions(merge: true));
  }

  static Future<Map<String, dynamic>> carregarStatus() async {
    final snap = await _doc.get();
    return Map<String, dynamic>.from(snap.data()?['status'] ?? {});
  }

  // Historico
  static Future<void> salvarHistorico(List<String> historico) async {
    await _doc.set({'historico': historico}, SetOptions(merge: true));
  }

  static Future<List<String>> carregarHistorico() async {
    final snap = await _doc.get();
    return List<String>.from(snap.data()?['historico'] ?? []);
  }

  // Cargo
  static Future<void> salvarCargo(String cargo) async {
    await _doc.update({'status.cargo': cargo});
  }

  static Future<String> carregarCargo() async {
    final snap = await _doc.get();
    return (snap.data()?['status']?['cargo'] ?? 'Pré-LEO') as String;
  }

  // Distribuição inicial
  static Future<void> salvarDistribuicaoInicial(bool valor) async {
    await _doc.set({'distribuiuInicial': valor}, SetOptions(merge: true));
  }

  static Future<bool> carregarDistribuicaoInicial() async {
    final snap = await _doc.get();
    return (snap.data()?['distribuiuInicial'] ?? false) as bool;
  }

  // Tutorial
  static Future<void> salvarTutorialVisto(bool valor) async {
    await _doc.set({'tutorialVisto': valor}, SetOptions(merge: true));
  }

  static Future<bool> carregarTutorialVisto() async {
    final snap = await _doc.get();
    return (snap.data()?['tutorialVisto'] ?? false) as bool;
  }

  // Ultimo XP
  static Future<void> salvarUltimoXPParaPontos(int xp) async {
    await _doc.set({'ultimoXPParaPontos': xp}, SetOptions(merge: true));
  }

  static Future<int> carregarUltimoXPParaPontos() async {
    final snap = await _doc.get();
    return (snap.data()?['ultimoXPParaPontos'] ?? 0) as int;
  }

  // Inicialização (primeiro uso)
  static Future<void> verificarInicializacao() async {
    final snap = await _doc.get();
    if (!snap.exists) {
      await _doc.set({
        'atributos': {
          'Oratória': 0,
          'Liderança': 0,
          'Empatia': 0,
          'Organização': 0,
        },
        'pontosDeAtributo': 3,
        'status': {
          'dinheiro': 100,
          'inteligencia': 0,
          'felicidade': 100,
          'saude': 100,
          'xp': 0,
          'idade': 18,
          'cargo': 'Pré-LEO',
        },
        'historico': [],
        'distribuiuInicial': false,
        'tutorialVisto': false,
        'ultimoXPParaPontos': 0,
      });
    }
  }

  static Future<void> salvarNomeJogador(String nome) async {
    await _doc.set({'nome': nome}, SetOptions(merge: true));
  }

  static Future<String?> carregarNomeJogador() async {
    final doc = await _doc.get();
    return doc.data()?['nome'] as String?;
  }

  static Future<void> salvarNomeClube(String nomeClube) async {
    await _doc.set({'nomeClube': nomeClube}, SetOptions(merge: true));
  }

  static Future<String?> getNomeClube() async {
    final doc = await _doc.get();
    return doc.data()?['clube'] as String?;
  }

  static Future<void> registrarResgateConquista(String titulo) async {
    final doc = await _doc.get();
    final atuais = List<String>.from(doc.data()?['conquistasResgatadas'] ?? []);
    if (!atuais.contains(titulo)) {
      atuais.add(titulo);
      await _doc.set({'conquistasResgatadas': atuais}, SetOptions(merge: true));
    }
  }

  static Future<List<String>> conquistasResgatadas() async {
    final doc = await _doc.get();
    return List<String>.from(doc.data()?['conquistasResgatadas'] ?? []);
  }

  static Future<Set<String>> conquistasDesbloqueadas() async {
    final doc = await _doc.get();
    return Set<String>.from(doc.data()?['conquistasDesbloqueadas'] ?? []);
  }

  static Future<void> desbloquear(String titulo) async {
    final desbloqueadas = await conquistasDesbloqueadas();
    if (!desbloqueadas.contains(titulo)) {
      desbloqueadas.add(titulo);
      await _doc.set({
        'conquistasDesbloqueadas': desbloqueadas.toList(),
      }, SetOptions(merge: true));
    }
  }

  static Future<bool> isDesbloqueada(String titulo) async {
    final desbloqueadas = await conquistasDesbloqueadas();
    return desbloqueadas.contains(titulo);
  }

  static Future<Map<String, bool>> listarTodas(List<String> titulos) async {
    final desbloqueadas = await conquistasDesbloqueadas();
    return {for (var titulo in titulos) titulo: desbloqueadas.contains(titulo)};
  }

  static Future<void> resetarConquistas() async {
    await _doc.set({'conquistasDesbloqueadas': []}, SetOptions(merge: true));
  }

  static Future<void> marcarInicioDoJogo() async {
    await desbloquear('Primeiro Passo');
  }

  static Future<void> marcarTelaVisitada(String telaId) async {
    final doc = await _doc.get();
    final visitadas = List<String>.from(doc.data()?['telasVisitadas'] ?? []);
    if (!visitadas.contains(telaId)) {
      visitadas.add(telaId);
      await _doc.set({'telasVisitadas': visitadas}, SetOptions(merge: true));
    }

    if (_telasPrincipais.every((t) => visitadas.contains(t))) {
      await desbloquear('Explorador');
    }
  }

  static final List<String> _telasPrincipais = [
    'actions',
    'profile',
    'conquistas',
    'name',
  ];
}
