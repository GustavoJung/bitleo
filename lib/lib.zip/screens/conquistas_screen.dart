import 'package:bitleo/services/atributos_storage.dart';
import 'package:flutter/material.dart';
import '../services/conquistas_service.dart';

class Conquista {
  final String titulo;
  final String descricao;
  bool desbloqueada;

  Conquista({
    required this.titulo,
    required this.descricao,
    this.desbloqueada = false,
  });

  Map<String, dynamic> toMap() => {
    'titulo': titulo,
    'descricao': descricao,
    'desbloqueada': desbloqueada,
  };

  static Conquista fromMap(Map<String, dynamic> map) => Conquista(
    titulo: map['titulo'],
    descricao: map['descricao'],
    desbloqueada: map['desbloqueada'],
  );
}

class ConquistasScreen extends StatefulWidget {
  const ConquistasScreen({super.key});

  @override
  State<ConquistasScreen> createState() => _ConquistasScreenState();
}

class _ConquistasScreenState extends State<ConquistasScreen> {
  List<Conquista> conquistas = [
    Conquista(
      titulo: 'Primeiro Passo',
      descricao: 'Você abriu o jogo pela primeira vez!',
    ),
    Conquista(
      titulo: 'Explorador',
      descricao: 'Visitou todas as telas principais.',
    ),
    Conquista(
      titulo: 'Ativo no clube',
      descricao: 'Realizou 10 ações no jogo.',
    ),
    Conquista(
      titulo: 'Começando a Jornada',
      descricao: 'Ganhou seus primeiros 10 de XP.',
    ),
    Conquista(
      titulo: 'Primeiro Passo de Liderança',
      descricao: 'Chegou a 50 de XP.',
    ),
    Conquista(titulo: 'Fala Bonita!', descricao: 'Atingiu 10 de Oratória.'),
    Conquista(
      titulo: 'Estrategista',
      descricao: 'Distribuiu seus pontos iniciais.',
    ),
    Conquista(
      titulo: 'Treta Controlada',
      descricao: 'Manteve a felicidade alta por 5 rodadas.',
    ),
    Conquista(titulo: 'Cura Total', descricao: 'Atingiu 100 de Saúde.'),
    Conquista(titulo: 'Maratona LEO', descricao: 'Jogou por 30 turnos.'),
  ];

  @override
  void initState() {
    super.initState();
    ConquistaService.marcarTelaVisitada('conquistas');
    _carregarConquistas();
  }

  Future<void> _carregarConquistas() async {
    final estados = await ConquistaService.listarTodas(
      conquistas.map((c) => c.titulo).toList(),
    );
    setState(() {
      for (var c in conquistas) {
        c.desbloqueada = estados[c.titulo] ?? false;
      }
    });
  }

  Future<bool> _verificarResgate(String titulo) async {
    final resgatadas = await ConquistaService.conquistasResgatadas();
    return resgatadas.contains(titulo);
  }

  Future<void> _resgatarRecompensa(String titulo) async {
    int pontosAtuais = await AtributosStorageFirestore.carregarPontos();
    await AtributosStorageFirestore.salvarPontos(pontosAtuais + 1);
    await ConquistaService.registrarResgate(titulo);
  }

  void _mostrarDetalhes(Conquista conquista) async {
    final jaResgatado = await _verificarResgate(conquista.titulo);

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF4A148C),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        title: Row(
          children: [
            const Icon(Icons.emoji_events, color: Colors.amber),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                conquista.titulo,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
        content: Text(
          '${conquista.descricao}\n\nRecompensa: +1 ponto de atributo',
          style: const TextStyle(color: Colors.white70),
        ),
        actions: [
          if (conquista.desbloqueada && !jaResgatado)
            TextButton(
              onPressed: () async {
                await _resgatarRecompensa(conquista.titulo);
                Navigator.of(context).pop();
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    backgroundColor: Colors.deepPurple,
                    behavior: SnackBarBehavior.floating,
                    content: SizedBox(
                      width: double.infinity,
                      child: Text(
                        'Recompensa resgatada com sucesso!',
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ),
                );
              },
              child: const Text(
                'Resgatar',
                style: TextStyle(color: Colors.white),
              ),
            ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text(
              'Fechar',
              style: TextStyle(color: Colors.white70),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Conta as desbloqueadas
    final desbloqueadas = conquistas.where((c) => c.desbloqueada).length;
    final total = conquistas.length;

    return WillPopScope(
      onWillPop: () async {
        Navigator.pop(context, true);
        return false; // Cancela o pop automático
      },
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Conquistas'),
          backgroundColor: const Color(0xFF3B1E5C),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.pop(context, true);
            },
          ),
        ),
        backgroundColor: const Color(
          0xFF3B1E5C,
        ), // Garantir cor de fundo do Scaffold
        body: Container(
          width: double.infinity,
          color: const Color(0xFF3B1E5C), // Fundo extra pra cobrir tudo
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 900),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(bottom: 16),
                      child: Text(
                        '$desbloqueadas de $total conquistas desbloqueadas',
                        style: const TextStyle(
                          color: Colors.white70,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    Wrap(
                      spacing: 16,
                      runSpacing: 16,
                      children: conquistas.map((conquista) {
                        return MouseRegion(
                          cursor: conquista.desbloqueada
                              ? SystemMouseCursors.click
                              : SystemMouseCursors.basic,
                          child: GestureDetector(
                            onTap: () => _mostrarDetalhes(conquista),
                            child: ConquistaCard(conquista: conquista),
                          ),
                        );
                      }).toList(),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class ConquistaCard extends StatelessWidget {
  final Conquista conquista;

  const ConquistaCard({super.key, required this.conquista});

  @override
  Widget build(BuildContext context) {
    final bool desbloqueada = conquista.desbloqueada;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      width: 220,
      height: 180,
      decoration: BoxDecoration(
        color: desbloqueada
            ? const Color(0xFF4A148C) // Roxo forte
            : const Color(0xFF2C2C2C), // Cinza escuro
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: desbloqueada ? Colors.amber.withOpacity(0.6) : Colors.white24,
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 6,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      padding: const EdgeInsets.all(16),
      child: Stack(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(
                desbloqueada ? Icons.emoji_events : Icons.lock_outline,
                color: desbloqueada ? Colors.amber : Colors.grey[400],
                size: 36,
              ),
              const SizedBox(height: 12),
              Text(
                conquista.titulo,
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: desbloqueada ? Colors.white : Colors.grey[400],
                ),
              ),
              const SizedBox(height: 8),
              Expanded(
                child: Text(
                  conquista.descricao,
                  style: TextStyle(
                    color: desbloqueada ? Colors.white70 : Colors.grey[500],
                    fontSize: 14,
                  ),
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          if (!desbloqueada)
            const Align(
              alignment: Alignment.topRight,
              child: Icon(Icons.lock, color: Colors.grey, size: 20),
            ),
        ],
      ),
    );
  }
}
