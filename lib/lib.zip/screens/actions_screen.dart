import 'dart:ui';
import 'package:flutter/material.dart';
import '../widgets/custom_appbar.dart';
import '../services/conquistas_service.dart';

class ActionsScreen extends StatelessWidget {
  final Function(Map<String, dynamic>, String) onActionSelected;
  final Function(String) onShowInfo;
  final Map<String, int> status;
  final Map<String, int> atributos;

  const ActionsScreen({
    super.key,
    required this.onActionSelected,
    required this.onShowInfo,
    required this.status,
    required this.atributos,
  });

  void showInfoDialog(BuildContext context, String title, String description) {
    ConquistaService.marcarTelaVisitada('actions');
    showDialog(
      context: context,
      builder: (context) {
        return Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.symmetric(
            horizontal: 24,
            vertical: 24,
          ),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 400),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(28),
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
                child: Container(
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.5),
                    borderRadius: BorderRadius.circular(28),
                    border: Border.all(color: Colors.white.withOpacity(0.1)),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(
                        Icons.info_outline,
                        size: 48,
                        color: Color(0xFFE1BEE7),
                      ),
                      const SizedBox(height: 12),
                      Text(
                        title,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: Color(0xFFD1B3FF),
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 12),
                      Text(
                        description,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: Colors.white70,
                          fontSize: 16,
                        ),
                      ),
                      const SizedBox(height: 24),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF6A1B9A),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30),
                            ),
                            padding: const EdgeInsets.symmetric(vertical: 14),
                          ),
                          onPressed: () => Navigator.pop(context),
                          child: const Text(
                            'Fechar',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  String getRequirementMessage(
    Map<String, dynamic> action,
    Map<String, int> status,
    Map<String, int> atributos,
  ) {
    List<String> mensagens = [];

    if ((action['label'] == 'Trabalhar' || action['label'] == 'Campanha') &&
        status['saude']! < 30) {
      mensagens.add(
        'Aumente sua saúde para realizar esta ação. Saúde necessária: 30 (atual: ${status['saude']})',
      );
    }
    if ((action['label'] == 'Campanha' || action['label'] == 'Estudar') &&
        status['felicidade']! < 20) {
      mensagens.add(
        'Aumente sua felicidade. Felicidade necessária: 20 (atual: ${status['felicidade']})',
      );
    }
    if (action['label'] == 'Estudar' && status['inteligencia']! < 15) {
      mensagens.add(
        'Aumente sua inteligência. Inteligência necessária: 15 (atual: ${status['inteligencia']})',
      );
    }

    final reqs = action['requisitos'] as Map<String, int>?;
    if (reqs != null) {
      for (final entry in reqs.entries) {
        final atual = atributos[entry.key] ?? 0;
        if (atual < entry.value) {
          mensagens.add(
            'Aumente seu atributo ${entry.key}. Necessário: ${entry.value} (atual: $atual)',
          );
        }
      }
    }

    if (mensagens.isEmpty) {
      return 'Você não pode realizar esta ação no momento.';
    }

    return mensagens.join('\n');
  }

  bool canPerformAction(
    Map<String, dynamic> action,
    Map<String, int> status,
    Map<String, int> atributos,
  ) {
    // Pré-requisitos fixos
    if ((action['label'] == 'Trabalhar' || action['label'] == 'Campanha') &&
        status['saude']! < 30)
      return false;
    if ((action['label'] == 'Campanha' || action['label'] == 'Estudar') &&
        status['felicidade']! < 20)
      return false;
    if (action['label'] == 'Estudar' && status['saude']! < 15) return false;

    // Pré-requisitos dinâmicos
    final reqs = action['requisitos'] as Map<String, int>?;
    if (reqs != null) {
      for (final entry in reqs.entries) {
        if ((atributos[entry.key] ?? 0) < entry.value) return false;
      }
    }

    return true;
  }

  String requirementText(
    Map<String, dynamic> action,
    Map<String, int> atributos,
  ) {
    List<String> reqs = [];

    if (action['label'] == 'Trabalhar' || action['label'] == 'Campanha') {
      reqs.add('Saúde ≥ 30');
    }
    if (action['label'] == 'Campanha' || action['label'] == 'Estudar') {
      reqs.add('Felicidade ≥ 20');
    }
    if (action['label'] == 'Estudar') {
      reqs.add('Inteligência ≥ 15');
    }

    final dinamicReqs = action['requisitos'] as Map<String, int>?;
    if (dinamicReqs != null) {
      for (final entry in dinamicReqs.entries) {
        final atual = atributos[entry.key] ?? 0;
        reqs.add('${entry.key} ≥ ${entry.value} (atual: $atual)');
      }
    }

    return reqs.join(', ');
  }

  @override
  Widget build(BuildContext context) {
    final status = this.status;
    final atributos = this.atributos;

    final actions = [
      {
        'label': 'Trabalhar',
        'description': 'Ganhe dinheiro, mas fique um pouco mais estressado.',
        'icon': Icons.work,
        'effects': {'dinheiro': 20, 'felicidade': -3, 'xp': 3},
        'info': 'Trabalhar aumenta sua renda, necessário para eventos e ações.',
      },
      {
        'label': 'Estudar',
        'description': 'Aumente sua inteligência e XP com dedicação.',
        'icon': Icons.school,
        'effects': {'inteligencia': 5, 'felicidade': -2, 'xp': 3},
        'info': 'Estudar ajuda a atingir cargos que exigem inteligência.',
      },
      {
        'label': 'Campanha',
        'description': 'Engaje a comunidade e evolua no clube.',
        'icon': Icons.volunteer_activism,
        'effects': {'felicidade': 5, 'xp': 5, 'dinheiro': -10},
        'info': 'Realizar campanhas dá XP para crescer no clube.',
      },
      {
        'label': 'Descansar',
        'description': 'Recupere saúde e bem-estar. Todo líder precisa disso!',
        'icon': Icons.bedtime,
        'effects': {'saude': 10, 'felicidade': 10, 'xp': 1},
        'info': 'Essencial para manter felicidade e saúde equilibradas.',
      },
      {
        'label': 'Organizar Evento',
        'description': 'Mostre sua liderança e ganhe XP.',
        'icon': Icons.event,
        'effects': {
          'organização': 3,
          'xp': 5,
          'felicidade': 2,
          'dinheiro': -10,
        },
        'info': 'Organizar eventos melhora sua organização e dá XP.',
      },
      {
        'label': 'Participar de Reunião',
        'description': 'Melhore sua oratória e ganhe experiência.',
        'icon': Icons.groups,
        'effects': {'oratória': 2, 'xp': 3},
        'info': 'Ótimo para desenvolver oratória e avançar nos cargos.',
      },
      {
        'label': 'Mentorar Novato',
        'description': 'Aumente sua empatia e fortaleça o clube.',
        'icon': Icons.support,
        'effects': {'empatia': 3, 'xp': 4, 'felicidade': 2},
        'info': 'Mentorar ajuda a crescer como líder e aumenta empatia.',
        'requisitos': {'Liderança': 10},
      },
      {
        'label': 'Redes Sociais',
        'description': 'Divulgue ações e mostre seu talento digital.',
        'icon': Icons.share,
        'effects': {'oratória': 2, 'organização': 1, 'xp': 4},
        'info': 'Trabalhar com redes melhora oratória e organização.',
      },
      {
        'label': 'Reunião Distrital',
        'description': 'Interaja com outros clubes e expanda sua visão.',
        'icon': Icons.location_city,
        'effects': {'oratória': 3, 'empatia': 2, 'xp': 6, 'dinheiro': -15},
        'info': 'Reuniões distritais são ótimas para conexões e XP.',
      },
    ];

    return Scaffold(
      appBar: buildCustomAppBar('Escolher Ação'),
      backgroundColor: const Color(0xFF3B1E5C),
      body: Center(
        child: Container(
          constraints: const BoxConstraints(maxWidth: 900),
          padding: const EdgeInsets.symmetric(vertical: 16),
          child: ListView.builder(
            itemCount: actions.length,
            itemBuilder: (context, index) {
              final action = actions[index];
              final pode = canPerformAction(action, status, atributos);
              final reqText = requirementText(action, atributos);

              final String label = action['label'] as String;
              final String description = action['description'] as String;
              final String info = action['info'] as String;
              final IconData icon = action['icon'] as IconData;
              final Map<String, dynamic> effects =
                  action['effects'] as Map<String, dynamic>;

              return Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 8,
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                    child: Opacity(
                      opacity: pode ? 1.0 : 0.4,
                      child: Container(
                        decoration: BoxDecoration(
                          color: const Color(0xFF6A1B9A).withOpacity(0.5),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                            color: Colors.white.withOpacity(0.1),
                          ),
                        ),
                        child: ListTile(
                          leading: Icon(
                            icon,
                            color: pode ? Colors.white : Colors.white38,
                            size: 32,
                          ),
                          title: Text(
                            label,
                            style: TextStyle(
                              color: pode ? Colors.white : Colors.white38,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          subtitle: Text(
                            description,
                            style: TextStyle(
                              color: pode ? Colors.white70 : Colors.white38,
                            ),
                          ),
                          trailing: Tooltip(
                            message: pode
                                ? 'Saiba mais'
                                : 'Você não pode realizar esta ação.\nRequisitos:\n$reqText',
                            child: IconButton(
                              icon: Icon(
                                Icons.info_outline,
                                color: pode ? Colors.white70 : Colors.white38,
                              ),
                              onPressed: () =>
                                  showInfoDialog(context, label, info),
                            ),
                          ),

                          onTap: pode
                              ? () {
                                  Navigator.pop(context);
                                  onActionSelected(effects, label);
                                }
                              : () {
                                  final mensagem = getRequirementMessage(
                                    action,
                                    status,
                                    atributos,
                                  );
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                      content: Text(
                                        mensagem,
                                        style: const TextStyle(
                                          color: Colors.white,
                                        ),
                                      ),
                                      backgroundColor: Colors.deepPurple,
                                      duration: const Duration(seconds: 4),
                                    ),
                                  );
                                },
                        ),
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
