import 'package:bitleo/services/conquistas_service.dart';
import 'package:flutter/material.dart';
import '../widgets/custom_appbar.dart';

class Conquista {
  final String titulo;
  final String descricao;
  bool desbloqueada;

  Conquista({
    required this.titulo,
    required this.descricao,
    this.desbloqueada = false,
  });

  Map<String, dynamic> toMap() => {
    'titulo': titulo,
    'descricao': descricao,
    'desbloqueada': desbloqueada,
  };

  static Conquista fromMap(Map<String, dynamic> map) => Conquista(
    titulo: map['titulo'],
    descricao: map['descricao'],
    desbloqueada: map['desbloqueada'],
  );
}

class ConquistasScreen extends StatefulWidget {
  const ConquistasScreen({super.key});

  @override
  State<ConquistasScreen> createState() => _ConquistasScreenState();
}

class _ConquistasScreenState extends State<ConquistasScreen> {
  List<Conquista> conquistas = [
    Conquista(
      titulo: 'Primeiro Passo',
      descricao: 'Você abriu o jogo pela primeira vez!',
    ),
    Conquista(
      titulo: 'Explorador',
      descricao: 'Visitou todas as telas principais.',
    ),
    Conquista(
      titulo: 'Ativo no clube',
      descricao: 'Realizou 10 ações no jogo.',
    ),
    Conquista(
      titulo: 'Começando a Jornada',
      descricao: 'Ganhou seus primeiros 10 de XP.',
    ),
    Conquista(
      titulo: 'Primeiro Passo de Liderança',
      descricao: 'Chegou a 50 de XP.',
    ),
    Conquista(titulo: 'Fala Bonita!', descricao: 'Atingiu 10 de Oratória.'),
    Conquista(
      titulo: 'Estrategista',
      descricao: 'Distribuiu seus pontos iniciais.',
    ),
    Conquista(
      titulo: 'Treta Controlada',
      descricao: 'Manteve a felicidade alta por 5 rodadas.',
    ),
    Conquista(titulo: 'Cura Total', descricao: 'Atingiu 100 de Saúde.'),
    Conquista(titulo: 'Maratona LEO', descricao: 'Jogou por 30 turnos.'),
  ];

  @override
  void initState() {
    super.initState();
    ConquistaService.marcarTelaVisitada('conquistas');
    _carregarConquistas();
  }

  Future<void> _carregarConquistas() async {
    final estados = await ConquistaService.listarTodas(
      conquistas.map((c) => c.titulo).toList(),
    );
    setState(() {
      for (var c in conquistas) {
        c.desbloqueada = estados[c.titulo] ?? false;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final total = conquistas.length;
    final desbloqueadas = conquistas.where((c) => c.desbloqueada).length;

    return Scaffold(
      appBar: buildCustomAppBar('Minhas Conquistas'),
      body: Container(
        color: const Color(0xFF1C1C1E),
        padding: const EdgeInsets.symmetric(horizontal: 48, vertical: 32),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '$desbloqueadas de $total conquistas desbloqueadas',
              style: const TextStyle(
                color: Colors.white70,
                fontSize: 20,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 28),
            Expanded(
              child: GridView.builder(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 4,
                  crossAxisSpacing: 20,
                  mainAxisSpacing: 20,
                  childAspectRatio: 0.9,
                ),
                itemCount: conquistas.length,
                itemBuilder: (context, index) {
                  final c = conquistas[index];
                  return GestureDetector(
                    onTap: () => showDialog(
                      context: context,
                      builder: (_) => AlertDialog(
                        backgroundColor: const Color(0xFF2E003E),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                        title: Text(
                          c.titulo,
                          style: const TextStyle(
                            color: Color(0xFFD1B3FF),
                            fontWeight: FontWeight.bold,
                            fontSize: 22,
                          ),
                        ),
                        content: Text(
                          c.descricao,
                          style: const TextStyle(
                            color: Colors.white70,
                            fontSize: 16,
                          ),
                        ),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.pop(context),
                            child: const Text(
                              'Fechar',
                              style: TextStyle(
                                color: Colors.deepPurpleAccent,
                                fontSize: 16,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 300),
                      decoration: BoxDecoration(
                        color: c.desbloqueada
                            ? const Color(0xFF3A0A5D)
                            : const Color(0xFF3A0A5D).withOpacity(0.3),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                          color: c.desbloqueada
                              ? const Color(0xFFD1B3FF)
                              : Colors.white24,
                          width: 1.2,
                        ),
                      ),
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.emoji_events,
                            color: c.desbloqueada
                                ? const Color.fromARGB(255, 230, 203, 85)
                                : Colors.white30,
                            size: 160,
                          ),
                          const SizedBox(height: 14),
                          Text(
                            c.titulo,
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 22,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            c.descricao,
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              color: Colors.white60,
                              fontSize: 16,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
